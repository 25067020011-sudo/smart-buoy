# SMMB — Desain UI/UX Dashboard

**Smart Marine Monitoring Buoy · Dashboard Streamlit · v1.1**

Dokumen ini menjabarkan desain antarmuka dashboard SMMB: prinsip, pengguna, arsitektur informasi, alur pengguna, design system, spesifikasi tiap halaman (wireframe), dan catatan implementasi Streamlit. Mockup visual ada di `04_UI_MOCKUP.html` (buka di browser).

Rujukan: PRD (`01_PRD.md`) Bagian 4, 7.6, dan 7.7 · skema data (`02_ERD_SCHEMA.md`).

---

## 1. Prinsip Desain

| # | Prinsip | Artinya di SMMB |
|---|---|---|
| 1 | **Status dulu, detail kemudian** | Dalam 5 detik pengguna tahu: buoy aman? data masuk? ada alarm? |
| 2 | **Kualitas data selalu terlihat** | Setiap titik data menunjukkan flag QC. Data mencurigakan tidak pernah tampil seolah-olah valid |
| 3 | **Jujur soal ketiadaan data** | Celah data tampil sebagai celah, bukan garis yang disambung |
| 4 | **Satu aksi utama per halaman** | Overview → cek status · Parameter → baca tren · Maintenance → isi form |
| 5 | **Lapangan-ready** | Halaman teknisi bisa dipakai dari HP, di perahu, dengan satu tangan |
| 6 | **Warna punya arti** | Hijau/kuning/merah hanya untuk status; parameter memakai warna tetap yang konsisten |
| 7 | **Bahasa Indonesia sederhana** | Istilah teknis diberi penjelasan singkat (tooltip) |

---

## 2. Pengguna & Tugas Utama

| Role | Perangkat utama | Tugas paling sering | Halaman utama |
|---|---|---|---|
| **Researcher** | Laptop | Melihat tren, membandingkan dengan pasang surut, unduh CSV | Parameter, Riwayat & Unduh, Validasi |
| **Technician** | HP | Menanggapi alarm, mencatat kunjungan dan pengukuran referensi | Overview, Maintenance |
| **Supervisor** | Laptop / HP | Melihat ringkasan ketersediaan data dan kemajuan | Overview |
| **Administrator** | Laptop | Kelola pengguna, ambang alarm, perangkat | Admin |

### Job stories

- *Saat* menerima notifikasi Telegram "buoy keluar geofence", *saya (teknisi) ingin* langsung melihat posisi terakhir dan jejaknya di peta, *agar* bisa memutuskan perlu turun ke laut atau tidak.
- *Saat* selesai mengukur dengan MPV di lokasi, *saya (teknisi) ingin* mengisi nilai referensi dalam < 2 menit dari HP, *agar* data validasi tidak tercecer di kertas.
- *Saat* menulis paper, *saya (peneliti) ingin* mengunduh data periode tertentu lengkap dengan flag QC dan ID kalibrasi, *agar* analisis dapat direproduksi.
- *Saat* rapat bulanan, *saya (supervisor) ingin* melihat persentase ketersediaan data per bulan, *agar* tahu apakah KPI ≥ 90% tercapai.

---

## 3. Arsitektur Informasi

```mermaid
flowchart TD
  L["Login"] --> O["1. Overview"]
  O --> P["2. Parameter"]
  O --> M["3. Peta"]
  O --> R["4. Riwayat & Unduh"]
  O --> V["5. Validasi & Kalibrasi"]
  O --> MT["6. Maintenance"]
  O --> A["7. Admin"]
  MT --> MT1["Form kunjungan"]
  MT --> MT2["Form pengukuran referensi"]
  MT --> MT3["Riwayat kunjungan"]
  A --> A1["Pengguna & role"]
  A --> A2["Perangkat & geofence"]
  A --> A3["Ambang QC & alarm"]
```

### Visibilitas menu per role

| Menu | Admin | Researcher | Supervisor | Technician |
|---|---|---|---|---|
| Overview | ✓ | ✓ | ✓ | ✓ |
| Parameter | ✓ | ✓ | ✓ | ✓ |
| Peta | ✓ | ✓ | ✓ | ✓ |
| Riwayat & Unduh | ✓ | ✓ | ✓ | — |
| Validasi & Kalibrasi | ✓ | ✓ | ✓ (lihat saja) | ✓ (lihat saja) |
| Maintenance | ✓ | ✓ | — | ✓ |
| Admin | ✓ | — | — | — |

Menu yang tidak berhak diakses **disembunyikan**, bukan ditampilkan lalu ditolak.

---

## 4. Alur Pengguna Utama

### 4.1 Menanggapi alarm (Technician)

```mermaid
flowchart TD
  A["Notifikasi Telegram masuk"] --> B["Ketuk tautan di pesan"]
  B --> C["Overview: kartu alarm aktif di paling atas"]
  C --> D{"Jenis alarm"}
  D -- Geofence --> E["Peta: posisi terakhir + jejak 24 jam"]
  D -- Baterai / data terhenti --> F["Overview: grafik baterai & sinyal 72 jam"]
  D -- Kebocoran --> G["Status perangkat: suhu & kelembapan enclosure"]
  E --> H["Tombol 'Saya tangani'"]
  F --> H
  G --> H
  H --> I["Status alarm: acknowledged + nama petugas"]
  I --> J["Setelah ditangani: 'Selesai' + catatan"]
```

### 4.2 Kunjungan lapangan (Technician, dari HP)

```mermaid
flowchart LR
  A["Maintenance"] --> B["+ Kunjungan baru"]
  B --> C["Isi: waktu, fase pasang, cuaca, aktivitas"]
  C --> D["Skor fouling 0-4 + foto"]
  D --> E["Simpan kunjungan"]
  E --> F["+ Pengukuran referensi"]
  F --> G["Pilih parameter, isi nilai, alat"]
  G --> H["Sistem cocokkan record buoy ±5 menit"]
  H --> I["Tampil selisih sensor vs referensi"]
  I --> J{"Selisih > ambang?"}
  J -- Ya --> K["Peringatan: jadwalkan kalibrasi ulang"]
  J -- Tidak --> L["Selesai"]
```

### 4.3 Unduh data untuk analisis (Researcher)

Riwayat & Unduh → pilih rentang tanggal → pilih parameter → pilih filter QC (semua / hanya lolos / tandai saja) → pratinjau 20 baris → **Unduh CSV**. Nama file otomatis: `SMMB-01_2027-03-01_2027-03-31_qc-all.csv`.

---

## 5. Design System

### 5.1 Warna

**Warna dasar (tema terang)**

| Token | Hex | Pemakaian |
|---|---|---|
| `primary` | `#0B5D7A` | Tombol utama, tautan, menu aktif (biru laut) |
| `primary-soft` | `#E3F1F6` | Latar elemen terpilih |
| `bg` | `#F7F9FA` | Latar halaman |
| `surface` | `#FFFFFF` | Kartu, panel |
| `border` | `#DDE3E7` | Garis kartu, pemisah |
| `text` | `#1B2730` | Teks utama |
| `text-muted` | `#5F6E78` | Label, keterangan |

**Warna status** — selalu disertai ikon atau teks, tidak hanya warna

| Status | Hex | Ikon | Contoh |
|---|---|---|---|
| Baik / lolos | `#1E8E5A` | ● | Online, QC lolos, baterai aman |
| Perhatian / mencurigakan | `#C98A0B` | ▲ | Baterai menurun, QC suspect |
| Kritis / gagal | `#C2412D` | ■ | Keluar geofence, kebocoran, QC gagal |
| Tidak ada data | `#9AA5AD` | ○ | Offline, data hilang |

**Warna parameter** — tetap di semua grafik

| Parameter | Hex |
|---|---|
| Suhu | `#D9622B` |
| Salinitas | `#1F6FB2` |
| Turbidity | `#8A6A3D` |
| pH | `#7A4FB5` |
| DO | `#1E9A8A` |

### 5.2 Tipografi

| Gaya | Ukuran | Berat | Pemakaian |
|---|---|---|---|
| Judul halaman | 24 px | 600 | Satu per halaman |
| Judul bagian | 18 px | 600 | Judul kartu/panel |
| Angka KPI | 28 px | 600 | Nilai terakhir di kartu |
| Isi | 14–15 px | 400 | Teks umum, tabel |
| Label kecil | 12 px | 500 | Satuan, timestamp, keterangan |

Font: bawaan Streamlit (Source Sans). Angka memakai `font-variant-numeric: tabular-nums` agar sejajar di tabel.

### 5.3 Spasi & bentuk

Kelipatan 8 px · radius kartu 10 px · bayangan tidak dipakai (garis 1 px saja) · lebar konten maksimum mengikuti `layout="wide"`.

### 5.4 Komponen

| Komponen | Isi | Aturan |
|---|---|---|
| **Kartu parameter** | Nama, nilai terakhir + satuan, perubahan 1 jam, badge QC, waktu ukur | Nilai flag 4 tampil "—" dengan badge merah; nilai lebih dari 30 menit lalu diberi label "data lama" |
| **Badge status** | Ikon + teks pendek | Contoh: "● Online", "▲ Baterai 11,9 V", "■ Keluar geofence" |
| **Grafik deret waktu** | Garis parameter, titik suspect (▲ kuning) dan gagal (■ merah), celah data | Garis putus di celah > 2 interval; sumbu waktu WIB; tooltip menampilkan nilai, flag, ID kalibrasi |
| **Pita kunjungan** | Garis vertikal tipis di grafik pada waktu kunjungan/kalibrasi | Membantu membaca lompatan setelah pembersihan |
| **Peta** | Titik tambat, lingkaran geofence, posisi terakhir, jejak | Posisi di luar geofence berwarna merah |
| **Kartu alarm** | Jenis, waktu, nilai pemicu, status, tombol aksi | Alarm terbuka selalu di atas halaman Overview |
| **Form lapangan** | Field besar, default terisi (waktu sekarang, buoy aktif) | Validasi langsung; tombol Simpan lebar penuh di HP |
| **Empty state** | Ilustrasi sederhana + kalimat + aksi | Contoh: "Belum ada kunjungan bulan ini. + Catat kunjungan" |

### 5.5 Microcopy

| Situasi | Teks |
|---|---|
| Data terakhir lebih dari 60 menit | "Data terakhir masuk 1 jam 20 menit lalu. Buoy mungkin kehilangan sinyal." |
| Nilai QC gagal | "Nilai ini di luar rentang wajar sensor dan tidak dipakai di grafik utama." |
| Unduh berhasil | "CSV berisi 2.976 baris siap diunduh." |
| Simpan referensi | "Tersimpan. Selisih dengan sensor: +0,4 PSU (dalam batas)." |
| Error koneksi | "Tidak bisa memuat data dari server. Coba muat ulang dalam beberapa saat." |

Semua waktu tampil dalam **WIB** dengan format `01 Mar 2027, 09:15 WIB`. Data tetap disimpan dalam UTC.

---

## 6. Spesifikasi Halaman

### 6.1 Overview

**Tujuan:** menjawab "apakah semuanya baik-baik saja?" dalam 5 detik.

```
┌──────────────────────────────────────────────────────────────────┐
│ SMMB-01 · Wonorejo        ● Online · data 4 menit lalu   [WIB ▾] │
├──────────────────────────────────────────────────────────────────┤
│ ■ ALARM: Baterai 11,7 V di bawah ambang · 08:45   [Saya tangani] │
├────────────┬────────────┬────────────┬────────────┬──────────────┤
│ Suhu       │ Salinitas  │ Turbidity  │ pH         │ DO           │
│ 30,4 °C    │ 28,6 PSU   │ 35,2 NTU   │ 8,02       │ 6,1 mg/L     │
│ ↑0,3 /1j ● │ ↓0,8 /1j ● │ ↑4,1 /1j ▲ │ ●          │ manual · 3hr │
├────────────┴────────────┴───────┬────┴────────────┴──────────────┤
│ Kesehatan perangkat             │ Ketersediaan data (30 hari)    │
│ Baterai  12,4 V  ▁▂▃▅▆▇ 72 jam  │ ███████████████████░  93,1 %   │
│ Sinyal   -79 dBm ●              │ Target ≥ 90 %  ●               │
│ Enclosure 36 °C · 58 % · kering │                                │
│ Posisi   12 m dari titik tambat │ Kunjungan terakhir: 3 hari lalu│
└─────────────────────────────────┴────────────────────────────────┘
```

- Kartu DO bertanda "manual" karena pada MVP DO diukur saat kunjungan (PRD Bagian 3).
- Pada HP, lima kartu parameter menjadi grid 2 kolom; kartu alarm tetap paling atas.
- Refresh otomatis setiap 60 detik.

### 6.2 Parameter

**Tujuan:** membaca tren dan kualitas data.

```
┌──────────────────────────────────────────────────────────────────┐
│ Rentang: [24 jam] [7 hari] [30 hari] [Kustom ▾]                  │
│ Parameter: [✓Suhu] [✓Salinitas] [✓Turbidity] [ pH] [ DO]         │
│ [✓] Tampilkan titik suspect/gagal   [✓] Tampilkan kunjungan      │
├──────────────────────────────────────────────────────────────────┤
│ Salinitas (PSU)                                                  │
│ 32 ┤        ╭──╮       ╭──╮          ╭──╮                        │
│ 28 ┤──╮   ╭─╯  ╰╮    ╭─╯  ╰─  ▲   ╭──╯  ╰──                      │
│ 24 ┤  ╰───╯     ╰────╯    (celah)  ╯                             │
│    └───────┬───────────┬──────────┬────────── waktu (WIB)        │
│            │kunjungan  │          │                              │
├──────────────────────────────────────────────────────────────────┤
│ Turbidity (NTU)  … grafik serupa, sumbu waktu disinkronkan       │
└──────────────────────────────────────────────────────────────────┘
```

- Satu grafik per parameter (bukan satu grafik dua sumbu Y), sumbu waktu disinkronkan.
- Opsi lapisan "pasang surut prediksi" sebagai area abu-abu tipis di latar (fase 2).

### 6.3 Peta

```
┌──────────────────────────────────────────┬───────────────────────┐
│                                          │ Posisi terakhir       │
│        ·  ·  · (jejak 24 jam)            │ 08:45 WIB             │
│      ·        ◯ geofence 50 m            │ 12 m dari tambat ●    │
│         ●  ← posisi terakhir             │                       │
│         ✚  ← titik tambat                │ Jejak: [24j][7h][30h] │
│                                          │ Kecepatan maks 0,4 m/s│
└──────────────────────────────────────────┴───────────────────────┘
```

- Koordinat presisi hanya untuk pengguna login; tampilan publik (bila ada) dibulatkan.
- Titik di luar geofence berwarna merah.

### 6.4 Riwayat & Unduh

Filter (rentang, parameter, filter QC) → tabel pratinjau dengan kolom flag berwarna → tombol **Unduh CSV** → catatan metadata (versi firmware, ID kalibrasi, definisi flag) ikut diunduh sebagai `README.txt` di dalam zip.

### 6.5 Validasi & Kalibrasi

```
┌───────────────────────────────┬──────────────────────────────────┐
│ Parameter: [Salinitas ▾]      │ Ringkasan (30 hari)              │
│                               │ n = 6 · Bias +0,4 PSU            │
│  Sensor vs Referensi          │ RMSE 0,7 PSU · R² 0,94           │
│  32┤            ● ●           │ Status: ● dalam batas (±1 PSU)   │
│  28┤      ● ●  /              │                                  │
│  24┤  ●  /     garis 1:1      │ Kalibrasi aktif: 12 Feb 2027     │
│    └──────────────            │ Berikutnya: ± 12 Mar 2027        │
├───────────────────────────────┴──────────────────────────────────┤
│ Selisih vs umur deployment (warna = skor fouling)                │
│ Riwayat kalibrasi: tanggal · metode · koefisien · petugas        │
└──────────────────────────────────────────────────────────────────┘
```

Grafik "selisih vs umur deployment dengan warna skor fouling" adalah visual inti untuk gap penelitian G2 (laju drift akibat biofouling).

### 6.6 Maintenance (mobile-first)

```
┌──────────────────────────┐
│ Kunjungan baru           │
│ Waktu   [11/03 09:10 ▾]  │
│ Pasang  (●Naik ○Turun …) │
│ Cuaca   [Cerah ▾]        │
│ Aktivitas                │
│ [✓]Bersih [✓]Ukur ref    │
│ [ ]Kalibrasi [ ]Perbaikan│
│ Fouling  0 1 [2] 3 4     │
│ Foto  [📷 Ambil foto]    │
│ Catatan [              ] │
│ [      SIMPAN       ]    │
└──────────────────────────┘
```

Setelah disimpan, muncul langsung form pengukuran referensi dengan kunjungan yang sama terpilih.

### 6.7 Admin

Tab: **Pengguna** (undang, ubah role, nonaktifkan) · **Perangkat** (titik tambat, radius geofence, interval, ambang baterai) · **QC & Alarm** (tabel ambang per parameter, aktif/nonaktif). Setiap perubahan meminta konfirmasi dan dicatat (siapa, kapan, nilai lama → baru).

---

## 7. Status Khusus

| Kondisi | Tampilan |
|---|---|
| Memuat | Skeleton kartu, bukan spinner layar penuh |
| Buoy offline > 60 menit | Banner abu-abu di atas + semua kartu bertanda "data lama" |
| Belum ada data (baru dipasang) | Empty state dengan checklist pemasangan |
| Server tidak terjangkau | Pesan error + waktu data terakhir yang tersimpan di cache |
| Tidak berhak akses | Menu disembunyikan; akses langsung lewat URL dialihkan ke Overview |

---

## 8. Aksesibilitas

- Kontras teks minimal 4,5 : 1 (WCAG AA).
- Status dan flag QC selalu memakai **ikon + teks**, tidak hanya warna (aman untuk buta warna).
- Target sentuh minimal 44 × 44 px di halaman Maintenance.
- Semua grafik punya ringkasan teks (nilai terakhir, min, maks) di atasnya.

---

## 9. Implementasi Streamlit

### 9.1 Struktur aplikasi

```
dashboard/
├── app.py                  # st.navigation + login + layout global
├── pages/
│   ├── 1_overview.py
│   ├── 2_parameter.py
│   ├── 3_peta.py
│   ├── 4_riwayat.py
│   ├── 5_validasi.py
│   ├── 6_maintenance.py
│   └── 7_admin.py
├── components/
│   ├── cards.py            # kartu parameter, badge status
│   ├── charts.py           # grafik Plotly dengan penanda QC
│   └── maps.py             # peta Folium
├── lib/
│   ├── db.py               # klien Supabase + query ter-cache
│   ├── auth.py             # login & role
│   └── fmt.py              # format WIB, angka, satuan
├── .streamlit/
│   ├── config.toml         # tema (boleh di-commit)
│   └── secrets.toml        # JANGAN di-commit
└── requirements.txt
```

### 9.2 Tema `.streamlit/config.toml`

```toml
[theme]
base = "light"
primaryColor = "#0B5D7A"
backgroundColor = "#F7F9FA"
secondaryBackgroundColor = "#FFFFFF"
textColor = "#1B2730"
```

### 9.3 Pola teknis

| Kebutuhan | Pola |
|---|---|
| Navigasi per role | `st.navigation()` dengan daftar halaman yang dibangun dari role pengguna |
| Login | Supabase Auth (email + password) via `supabase-py`; sesi di `st.session_state` |
| Cache query | `@st.cache_data(ttl=60)` untuk data terbaru, `ttl=3600` untuk data historis |
| Refresh otomatis Overview | `@st.fragment(run_every="60s")` pada blok kartu, bukan seluruh halaman |
| Kartu nilai | `st.metric` atau HTML kecil di `components/cards.py` |
| Grafik | Plotly: garis + scatter khusus untuk flag 3 dan 4; `connectgaps=False` |
| Peta | `streamlit-folium` + OpenStreetMap |
| Data besar | Agregasi di database (view per jam) untuk rentang > 7 hari |
| Zona waktu | Konversi UTC → `Asia/Jakarta` hanya di lapisan tampilan (`lib/fmt.py`) |

Catatan: dashboard hanya **membaca** data sensor dan **menulis** data lapangan/admin. Dashboard tidak pernah menerima data dari ESP32 (lihat PRD 7.1).

---

## 10. Checklist Review Desain

- [ ] Status buoy terbaca dalam 5 detik di Overview
- [ ] Setiap nilai menampilkan flag QC dan waktu ukur
- [ ] Celah data tidak disambung
- [ ] Alarm terbuka selalu di atas
- [ ] Form Maintenance bisa diisi < 2 menit dari HP
- [ ] Menu sesuai role
- [ ] Semua waktu dalam WIB
- [ ] Status memakai ikon + teks
- [ ] Tidak ada koordinat presisi pada tampilan publik
