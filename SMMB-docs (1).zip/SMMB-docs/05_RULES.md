# SMMB — Project Rules

**Smart Marine Monitoring Buoy · aturan pengembangan, data, dan lapangan · v1.1**

Aturan ini berlaku untuk semua anggota tim **dan** asisten AI (Claude, Copilot, Cursor, dll.) yang bekerja di repositori SMMB. Simpan file ini di root repositori sebagai `RULES.md`. Untuk asisten AI, salin isinya ke `CLAUDE.md` / `.cursorrules` / `AGENTS.md`.

Tingkat aturan:

- **WAJIB** — tidak boleh dilanggar. Pelanggaran = PR ditolak atau pekerjaan diulang.
- **SEBAIKNYA** — dilakukan kecuali ada alasan yang ditulis.

Rujukan: `01_PRD.md` · `02_ERD_SCHEMA.md` · `03_UI_UX.md`

---

## 1. Aturan Inti (baca ini dulu)

1. **WAJIB** — Data mentah tidak pernah dihapus atau diubah. Koreksi dilakukan dengan flag QC atau kolom/tabel turunan, bukan menimpa nilai asli.
2. **WAJIB** — Tidak ada secret di GitHub: API key, service role key, token Telegram, password, isi `secrets.toml`.
3. **WAJIB** — Semua waktu disimpan dalam **UTC**. Konversi ke WIB hanya di tampilan.
4. **WAJIB** — Setiap nilai sensor bisa ditelusuri ke versi firmware dan kalibrasi yang berlaku.
5. **WAJIB** — Tidak ada pemasangan di laut sebelum izin diperoleh dan Go/No-Go (PRD 11.5) lulus.
6. **WAJIB** — Perubahan yang menyimpang dari PRD harus disetujui peneliti utama dan dicatat di riwayat perubahan PRD.

---

## 2. Repositori & Git

### 2.1 Struktur

```
smmb/
├── firmware/            # ESP32 (Arduino / PlatformIO)
├── dashboard/           # Streamlit
├── db/                  # SQL berurutan + Edge Functions
├── analysis/            # notebook & skrip QC/analisis
├── docs/                # PRD, ERD, UI/UX, SOP, form lapangan
├── .github/workflows/   # CI & tugas terjadwal
├── RULES.md
└── README.md
```

### 2.2 Branch & commit

| Aturan | Tingkat |
|---|---|
| `main` selalu bisa di-deploy; tidak ada push langsung ke `main` | WAJIB |
| Branch: `feat/…`, `fix/…`, `docs/…`, `data/…`, `fw/…` | SEBAIKNYA |
| Commit pakai format Conventional Commits: `feat(dashboard): kartu alarm di overview` | SEBAIKNYA |
| Satu PR = satu perubahan logis; sertakan referensi FR/NFR dari PRD | SEBAIKNYA |
| PR yang menyentuh `db/` atau `firmware/` direview minimal 1 orang lain | WAJIB |

### 2.3 Secret & file terlarang

`.gitignore` minimal berisi:

```gitignore
.streamlit/secrets.toml
.env
*.env
firmware/include/secrets.h
data/raw/
*.csv
__pycache__/
.ipynb_checkpoints/
```

- **WAJIB** — Secret disimpan di `st.secrets` (Streamlit Cloud), GitHub Secrets (Actions), dan Supabase Secrets (Edge Functions).
- **WAJIB** — Sediakan file contoh tanpa nilai: `secrets.toml.example`, `secrets.h.example`.
- **WAJIB** — Jika secret sempat ter-commit: anggap bocor, **rotasi key segera**, baru bersihkan riwayat Git.
- **WAJIB** — CI menjalankan pemindai secret (mis. gitleaks) di setiap PR.
- **WAJIB** — Jika repositori publik: tidak ada koordinat presisi titik tambat di kode, dokumen, maupun contoh data.

---

## 3. Firmware (ESP32)

| # | Aturan | Tingkat |
|---|---|---|
| F1 | Simpan ke microSD **sebelum** mencoba mengirim (store-and-forward) | WAJIB |
| F2 | `seq` naik terus dan disimpan di memori non-volatile; tidak pernah reset saat reboot | WAJIB |
| F3 | Timestamp dari RTC dalam UTC, disinkronkan GPS/NTP secara berkala | WAJIB |
| F4 | Watchdog aktif; tidak ada loop tanpa batas waktu | WAJIB |
| F5 | Modul 4G, GPS, dan sensor dimatikan saat tidak dipakai; ESP32 masuk deep sleep | WAJIB |
| F6 | Setiap pengiriman punya timeout dan retry terbatas; gagal = tetap di antrian, bukan dibuang | WAJIB |
| F7 | Nilai sensor yang gagal dibaca dikirim sebagai `null`, bukan 0 atau nilai lama | WAJIB |
| F8 | Versi firmware (`fw`) dikirim di setiap record; versi naik di setiap rilis (SemVer) | WAJIB |
| F9 | Konstanta kalibrasi **tidak** di-hardcode di firmware; koreksi dilakukan di server/analisis | SEBAIKNYA |
| F10 | Baca beberapa sampel per siklus dan kirim median | SEBAIKNYA |
| F11 | Uji perubahan firmware di bench minimal 24 jam sebelum di-flash ke buoy lapangan | WAJIB |
| F12 | Nama variabel dan kolom menyertakan satuan: `temp_c`, `batt_v`, `turb_ntu` | WAJIB |

---

## 4. Database (Supabase)

| # | Aturan | Tingkat |
|---|---|---|
| D1 | Semua perubahan skema lewat file SQL bernomor di `db/` (migrasi), tidak lewat klik di dashboard Supabase | WAJIB |
| D2 | Row Level Security aktif di **setiap** tabel | WAJIB |
| D3 | Service role key hanya di Edge Function; tidak pernah di ESP32, dashboard, atau notebook bersama | WAJIB |
| D4 | ESP32 menulis hanya lewat Edge Function `ingest` dengan API key per perangkat | WAJIB |
| D5 | Tidak ada `DELETE` atau `UPDATE` nilai sensor di `measurements`; yang boleh diperbarui hanya `qc_flags` | WAJIB |
| D6 | `calibrations` bersifat append-only: kalibrasi baru = baris baru, bukan mengedit baris lama | WAJIB |
| D7 | Insert data sensor selalu idempoten: `on conflict (device_id, seq) do nothing` | WAJIB |
| D8 | Backup terjadwal (GitHub Actions) minimal mingguan, disimpan di luar Supabase | WAJIB |
| D9 | Query untuk rentang > 7 hari memakai agregasi/view, bukan menarik semua baris | SEBAIKNYA |

---

## 5. Dashboard (Streamlit)

| # | Aturan | Tingkat |
|---|---|---|
| S1 | Dashboard tidak menerima data dari ESP32 dan tidak menjalankan proses latar belakang penting | WAJIB |
| S2 | Kunci yang dipakai dashboard = anon key + login pengguna; hak akses diatur RLS | WAJIB |
| S3 | Menu ditampilkan sesuai role (`03_UI_UX.md` Bagian 3) | WAJIB |
| S4 | Data dengan flag 4 tidak tampil di grafik utama; flag 3 ditandai | WAJIB |
| S5 | Celah data tidak disambung (`connectgaps=False`) | WAJIB |
| S6 | Semua query memakai `@st.cache_data` dengan `ttl` | SEBAIKNYA |
| S7 | Warna, ikon status, dan microcopy mengikuti design system di `03_UI_UX.md` | SEBAIKNYA |
| S8 | `requirements.txt` mengunci versi utama paket (mis. `streamlit>=1.40,<2`) | SEBAIKNYA |

---

## 6. Data & Integritas Ilmiah

| # | Aturan | Tingkat |
|---|---|---|
| R1 | Data mentah, data ber-flag, dan data terkoreksi disimpan terpisah dan diberi nama jelas | WAJIB |
| R2 | Setiap kalibrasi dicatat: tanggal, larutan standar (merek, lot, kedaluwarsa), hasil, koefisien, petugas | WAJIB |
| R3 | Setiap pengukuran referensi dicatat di sistem pada hari yang sama (bukan hanya di kertas) | WAJIB |
| R4 | Koreksi drift dan model (mis. virtual DO) disimpan sebagai kode di `analysis/` dengan versi, bukan diedit manual di spreadsheet | WAJIB |
| R5 | Ambang QC dan perubahannya didokumentasikan beserta alasannya | WAJIB |
| R6 | Data tidak dibuang karena "terlihat aneh"; diberi flag dan alasannya dicatat | WAJIB |
| R7 | Statistik validasi (bias, RMSE, R²) dilaporkan dengan jumlah pasangan data (n) | WAJIB |
| R8 | Analisis untuk paper dapat direproduksi dari repositori + dataset rilis | WAJIB |
| R9 | Dataset rilis publik memakai koordinat dibulatkan, disertai README, definisi flag, dan lisensi | WAJIB |
| R10 | Foto fouling diambil dengan sudut dan jarak yang sama setiap kunjungan | SEBAIKNYA |

---

## 7. Lapangan & Keselamatan

| # | Aturan | Tingkat |
|---|---|---|
| L1 | Kerja di air minimal 2 orang, semua memakai pelampung | WAJIB |
| L2 | Cek prakiraan cuaca BMKG dan jadwal pasang surut sebelum berangkat; batal jika ada peringatan | WAJIB |
| L3 | Beri tahu kontak darat (rencana berangkat dan perkiraan kembali) | WAJIB |
| L4 | Ikuti checklist kunjungan: bersihkan → foto → ukur referensi → catat → cek fisik buoy dan mooring | WAJIB |
| L5 | Bahan kimia kalibrasi dibawa dan dibuang sesuai SDS; tidak dibuang ke laut | WAJIB |
| L6 | Kerusakan, kehilangan, atau insiden dilaporkan ke peneliti utama hari itu juga | WAJIB |
| L7 | Komunikasi dengan mitra masyarakat dicatat (tanggal, isi, tindak lanjut) | SEBAIKNYA |

---

## 8. Aturan untuk Asisten AI

Bagian ini untuk alat AI yang membantu menulis kode atau dokumen di repositori ini.

1. **Ikuti PRD, ERD, dan UI/UX sebagai sumber kebenaran.** Jika permintaan bertentangan dengan dokumen, sebutkan konfliknya dan tanyakan dulu.
2. **Jangan mengubah skema database** (tabel, kolom, enum, RLS) tanpa diminta eksplisit. Jika perlu, buat file migrasi baru bernomor, jangan mengedit migrasi lama.
3. **Jangan mengarang spesifikasi sensor**, harga, akurasi, atau hasil uji. Tulis "perlu diverifikasi" jika tidak tahu.
4. **Jangan menulis secret** ke file apa pun, termasuk contoh. Gunakan placeholder `<SUPABASE_URL>`.
5. **Jangan membuat kode yang menghapus atau menimpa data sensor.**
6. **Pertahankan konvensi:** UTC di penyimpanan, satuan di nama kolom, `seq` untuk deduplikasi, flag QC 1/2/3/4/9.
7. **Kode harus bisa diuji:** sertakan atau perbarui test untuk logika QC, konversi satuan, dan parsing payload.
8. **Bahasa:** komentar kode dan nama variabel dalam bahasa Inggris; teks yang dilihat pengguna (UI, pesan alarm) dalam bahasa Indonesia.
9. **Jelaskan perubahan** di deskripsi PR: apa, mengapa, FR/NFR yang terkait, dan cara mengujinya.

---

## 9. Konvensi Penamaan

| Hal | Format | Contoh |
|---|---|---|
| ID perangkat | `SMMB-NN` | `SMMB-01` |
| Kolom nilai | `<besaran>_<satuan>` | `sal_psu`, `turb_ntu`, `batt_v` |
| Tabel | snake_case, jamak | `measurements`, `field_visits` |
| File migrasi | `NN_deskripsi.sql` | `07_add_solar_current.sql` |
| ID kalibrasi (tampilan) | `cal-YYYY-MM-DD` | `cal-2027-02-12` |
| File unduhan | `<device>_<dari>_<sampai>_qc-<filter>.csv` | `SMMB-01_2027-03-01_2027-03-31_qc-all.csv` |
| Versi firmware | SemVer | `1.0.3` |
| Foto lapangan | `<device>_<YYYYMMDD>_<sudut>.jpg` | `SMMB-01_20270311_probe.jpg` |

---

## 10. Definition of Done

Sebuah pekerjaan dianggap selesai jika:

- [ ] Memenuhi requirement PRD yang dirujuk (FR/NFR-xx)
- [ ] Lulus CI: lint, test, pemindai secret
- [ ] Direview (wajib untuk `db/` dan `firmware/`)
- [ ] Dokumentasi diperbarui (README, SOP, atau PRD jika ada perubahan)
- [ ] Tidak ada secret atau koordinat presisi di diff
- [ ] Untuk firmware: lulus uji bench 24 jam
- [ ] Untuk dashboard: dicek di laptop **dan** HP
- [ ] Untuk analisis: dapat dijalankan ulang dari awal dan menghasilkan angka yang sama
