"""SMMB Dataset Quality Assessment (DQA).

Input  : measurements.csv, reference.csv (export from Supabase views)
Output : per-parameter, per-month quality metrics + grade (A/B/C/D)
Usage  : python dqa.py measurements.csv reference.csv --interval 15 --out dqa_report.csv
"""
import argparse
import json
import numpy as np
import pandas as pd

# column -> (tolerance, relative_tolerance_fraction or None)
TOL = {
    "temp_c":   (0.5, None),
    "sal_psu":  (1.0, None),
    "turb_ntu": (5.0, 0.10),   # max(5 NTU, 10 % of reference)
    "ph":       (0.2, None),
    "do_mgl":   (0.5, None),   # adjust to reference instrument spec
}
PARAM = {"temp": "temp_c", "salinity": "sal_psu", "turbidity": "turb_ntu", "ph": "ph", "do": "do_mgl"}


def load(meas_path, ref_path=None):
    m = pd.read_csv(meas_path, parse_dates=["ts_utc", "received_at"])
    m["qc_flags"] = m["qc_flags"].fillna("{}").apply(json.loads)
    r = pd.read_csv(ref_path, parse_dates=["measured_at", "sensor_ts"]) if ref_path else None
    return m, r


def flag(m, col):
    return m["qc_flags"].apply(lambda f: f.get(col, 2))


def completeness(m, col, interval_min, start, end):
    """start/end: deployment window clipped to the month being assessed."""
    span_min = (end - start).total_seconds() / 60
    expected = int(span_min // interval_min) + 1
    received = m[col].notna().sum()
    return received / expected if expected else np.nan, received, expected


def validity(m, col):
    f = flag(m, col)[m[col].notna()]
    return (f == 1).mean() if len(f) else np.nan


def timeliness(m):
    lat = (m["received_at"] - m["ts_utc"]).dt.total_seconds() / 60
    return lat.median(), lat.quantile(0.95)


def gap_stats(m, interval_min):
    d = m.sort_values("ts_utc")["ts_utc"].diff().dt.total_seconds() / 60
    gaps = d[d > 2 * interval_min]
    return len(gaps), (gaps.max() / 60 if len(gaps) else 0.0)


def accuracy(r, col):
    """r: validation pairs with columns parameter, ref_value, sensor_value."""
    p = [k for k, v in PARAM.items() if v == col][0]
    x = r[r["parameter"] == p].dropna(subset=["ref_value", "sensor_value"])
    if len(x) < 2:
        return dict(n=len(x), bias=np.nan, mae=np.nan, rmse=np.nan, r2=np.nan, loa_lo=np.nan, loa_hi=np.nan, within_tol=np.nan)
    e = x["sensor_value"] - x["ref_value"]
    tol_abs, tol_rel = TOL[col]
    tol = np.maximum(tol_abs, (tol_rel or 0) * x["ref_value"].abs())
    r2 = (np.corrcoef(x["ref_value"], x["sensor_value"])[0, 1] ** 2
          if x["ref_value"].std() > 0 and x["sensor_value"].std() > 0 else np.nan)
    sd = e.std(ddof=1)
    return dict(n=len(x), bias=e.mean(), mae=e.abs().mean(), rmse=np.sqrt((e ** 2).mean()), r2=r2,
                loa_lo=e.mean() - 1.96 * sd, loa_hi=e.mean() + 1.96 * sd, within_tol=(e.abs() <= tol).mean())


def drift_rate(r, col):
    """Slope of (sensor - ref) vs days since last calibration (unit/day)."""
    p = [k for k, v in PARAM.items() if v == col][0]
    x = r[(r["parameter"] == p)].dropna(subset=["ref_value", "sensor_value", "days_since_calib"])
    if len(x) < 3:
        return np.nan
    return np.polyfit(x["days_since_calib"], x["sensor_value"] - x["ref_value"], 1)[0]


def grade(c, v, acc, col):
    tol = TOL[col][0]
    b, rm, n = acc["bias"], acc["rmse"], acc["n"]
    has_val = n >= 3 and not np.isnan(rm)
    if c >= 0.90 and v >= 0.95 and has_val and abs(b) <= tol / 2 and rm <= tol:
        return "A"
    if c >= 0.80 and v >= 0.90 and has_val and rm <= 1.5 * tol:
        return "B"
    if c >= 0.60 and v >= 0.75:
        return "C"
    return "D"


def assess(m, r, interval_min=15):
    rows = []
    m = m.copy()
    dup_rate = m.duplicated(["device_id", "seq"]).groupby(m["ts_utc"].dt.strftime("%Y-%m")).mean()
    m = m.drop_duplicates(["device_id", "seq"])          # assess unique records only
    first, last = m["ts_utc"].min(), m["ts_utc"].max()   # deployment window
    m["month"] = m["ts_utc"].dt.strftime("%Y-%m")
    if r is not None:
        r = r.copy()
        r["month"] = r["measured_at"].dt.strftime("%Y-%m")
    for month, mm in m.groupby("month"):
        rr = r[r["month"] == month] if r is not None else pd.DataFrame(columns=["parameter"])
        u = 1 - dup_rate.get(month, 0.0)
        m0 = pd.Timestamp(month + "-01", tz=mm["ts_utc"].dt.tz)
        start = max(first, m0)
        end = min(last, m0 + pd.offsets.MonthBegin(1) - pd.Timedelta(minutes=interval_min))
        lat50, lat95 = timeliness(mm)
        ngap, maxgap_h = gap_stats(mm, interval_min)
        for col in TOL:
            if col not in mm or mm[col].notna().sum() == 0:
                continue
            c, rec, exp = completeness(mm, col, interval_min, start, end)
            v = validity(mm, col)
            acc = accuracy(rr, col) if len(rr) else accuracy(pd.DataFrame(columns=["parameter", "ref_value", "sensor_value"]), col)
            dr = drift_rate(rr, col) if len(rr) and "days_since_calib" in rr else np.nan
            trace = mm.loc[mm[col].notna(), ["fw_version", "calib_ids"]].notna().all(axis=1).mean()
            rows.append(dict(month=month, parameter=col, received=rec, expected=exp,
                             completeness=round(c, 4), validity=round(v, 4), uniqueness=round(u, 4),
                             latency_p50_min=round(lat50, 1), latency_p95_min=round(lat95, 1),
                             gaps=ngap, max_gap_h=round(maxgap_h, 1), traceability=round(trace, 4),
                             **{k: (round(val, 3) if isinstance(val, float) else val) for k, val in acc.items()},
                             drift_per_day=round(dr, 4) if not np.isnan(dr) else np.nan,
                             grade=grade(c, v, acc, col)))
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("measurements")
    ap.add_argument("reference", nargs="?")
    ap.add_argument("--interval", type=int, default=15)
    ap.add_argument("--out", default="dqa_report.csv")
    a = ap.parse_args()
    m, r = load(a.measurements, a.reference)
    rep = assess(m, r, a.interval)
    rep.to_csv(a.out, index=False)
    print(rep.to_string(index=False))
