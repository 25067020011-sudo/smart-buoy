# SMMB — Dokumen Proyek

**Smart Marine Monitoring Buoy** · IoT-Based Coastal Water Quality Monitoring System · Surabaya · v1.1

| File | Isi |
|---|---|
| `01_PRD.md` | Product Requirements Document v1.1: strategi pengukuran, kerangka penelitian & diagram alir, FR/NFR, hardware & power budget, arsitektur GitHub + Streamlit + Supabase, anggaran, roadmap, acceptance criteria, risk register, 10 research gap untuk Q1 |
| `02_ERD_SCHEMA.md` | ERD (Mermaid), skema SQL PostgreSQL/Supabase, trigger QC & alarm, view, Row Level Security, kontrak payload ESP32 |
| `03_UI_UX.md` | Desain UI/UX dashboard: prinsip, pengguna, arsitektur informasi, user flow, design system, wireframe 7 halaman, catatan implementasi Streamlit |
| `04_UI_MOCKUP.html` | Mockup visual dashboard (buka di browser; data contoh). Ganti role di sidebar untuk melihat menu per role |
| `05_RULES.md` | Aturan proyek: Git & secret, firmware, database, dashboard, integritas data, keselamatan lapangan, aturan asisten AI, Definition of Done |

## Cara membaca

1. Mulai dari `01_PRD.md` (Bagian 0 berisi ringkasan perubahan).
2. Developer backend → `02_ERD_SCHEMA.md` lalu `05_RULES.md` Bagian 4.
3. Developer dashboard → `03_UI_UX.md` + `04_UI_MOCKUP.html` lalu `05_RULES.md` Bagian 5.
4. Tim firmware & lapangan → `05_RULES.md` Bagian 3 dan 7.

## Penempatan di repositori GitHub

```
smmb/
├── docs/
│   ├── 01_PRD.md
│   ├── 03_UI_UX.md
│   └── 04_UI_MOCKUP.html
├── db/
│   └── 02_ERD_SCHEMA.md   (pecah menjadi file .sql bernomor)
├── RULES.md               (= 05_RULES.md)
└── README.md
```

Diagram Mermaid di file `.md` tampil otomatis di GitHub.

Semua angka anggaran, spesifikasi, dan ambang di dokumen ini adalah estimasi perencanaan dan perlu diverifikasi.
